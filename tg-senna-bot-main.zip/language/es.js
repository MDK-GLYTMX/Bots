
exports.menu = async (conn, thumbnail, pushname, OWNER_NAME, OWNER, prefix, os, simple, week, date, username, isCreator, user_id) => {
	
const runtimeInSeconds = process.uptime();
const days = Math.floor(runtimeInSeconds / (60 * 60 * 24));
const hours = Math.floor((runtimeInSeconds % (60 * 60 * 24)) / (60 * 60));
const minutes = Math.floor((runtimeInSeconds % (60 * 60)) / 60);
const seconds = Math.floor(runtimeInSeconds % 60);

const runtimeFormatted = `${days}d ${hours}h ${minutes}m`


    let ini_anu = `Hola ${pushname}

┌─⊷ Senna
▢ Creador :  [@${OWNER_NAME}](${OWNER[0]})
▢ Prefix :   ${prefix}
▢ Runtime : ${runtimeFormatted}
▢ Fecha : ${week}, ${date}
└──────────
┌─⊷ User Info
▢ Nombre : ${pushname}
▢ Tag : [@${pushname}](https://t.me/${username})
▢ Owner : ${isCreator ? 'True' : `False`}
└──────────
`
    var button = [
        [{
                text: '⦙☰ Menu',
                callback_data: 'allmenu ' + user_id
            }
        ],
        [{
                text: '👑 Owner',
                callback_data: 'owner ' + user_id
            }
        ],
    ]

        await conn.replyWithPhoto({
            source: thumbnail
        }, {
            caption: ini_anu,
            parse_mode: "MARKDOWN",
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: button
            }
        })
    
}


exports.allmenu = async (conn, thumbnail, user_id) => {
    var button = [
        [{
            text: '👑 Owner',
            callback_data: 'owner ' + user_id
        }, ]
    ]
    
    let caption = `  ≡ LISTA DE MENUS
   
┌─⊷ ACERCA DE
▢ /runtime 
▢ /ping
└───────────
┌─⊷ DESCARGAS
▢ /play
▢ /ytmp4
▢ /ytmp3
▢ /tiktok 
▢ /instagram
└───────────
┌─⊷ TOOLS
▢ /ia
▢ /gemini
└───────────
┌─⊷ IMAGEN
▢ /tvid
▢ /couple
▢ /imagen
└───────────
`
    await conn.editMessageMedia({
        type: "photo",
        media: {
            source: thumbnail
        },
        caption: caption
    }, {
        parse_mode: "MARKDOWN",
        disable_web_page_preview: true,
        reply_markup: {
            inline_keyboard: button
        }
    })
}
