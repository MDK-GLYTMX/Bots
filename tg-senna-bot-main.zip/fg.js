require("./settings")
const {
    Telegraf,
    Context
} = require('telegraf')
const {
    simple
} = require("./lib/myfunc")
const fs = require('fs')
const os = require('os')
const axios = require('axios')
const speed = require('performance-now')

const yts = require('yt-search')
const fgdl = require('./lib/ytdl-core')
const tele = require('./lib/tele')

if (BOT_TOKEN == 'YOUR_TELEGRAM_BOT_TOKEN') {
    return console.log(`no hay token`)
}

global.API = (name, path = '/', query = {}, apikeyqueryname) => (name in global.APIs ? global.APIs[name] : name) + path + (query || apikeyqueryname ? '?' + new URLSearchParams(Object.entries({
    ...query,
    ...(apikeyqueryname ? {
        [apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name] : name]
    } : {})
})) : '')

const bot = new Telegraf(BOT_TOKEN)

//--- welcome 
bot.on('new_chat_members', async (conn) => {
	let message = conn.message
	let pp_group = await tele.getPhotoProfile(message.chat.id)
	let groupname = message.chat.title
	let groupmembers = await bot.telegram.getChatMembersCount(message.chat.id)
	for (x of message.new_chat_members) {
		let pp_user = await tele.getPhotoProfile(x.id)
		let full_name = tele.getUser(x).full_name
		
        let wel = global.API('fgmods', '/api/welcome', {
                                username: full_name, 
                                groupname: groupname, 
                                groupicon: pp_group,
                                membercount: groupmembers,
                                profile: pp_user,
                                background: 'https://i.ibb.co/fkFmQC2/eve.jpg'
                            }, 'apikey')
		 	await conn.replyWithPhoto({ url: wel })
	}
})

//--- leave 
bot.on('left_chat_member', async (conn) => {
	let message = conn.message
	let pp_group = await tele.getPhotoProfile(message.chat.id)
	let groupname = message.chat.title
	let groupmembers = await bot.telegram.getChatMembersCount(message.chat.id)
	let pp_user = await tele.getPhotoProfile(message.left_chat_member.id)
	let full_name = tele.getUser(message.left_chat_member).full_name
		
    let lea = global.API('fgmods', '/api/goodbye', {
                            username: full_name,
                            groupname: groupname, 
                            groupicon: pp_group,
                            membercount: groupmembers,
                            profile: pp_user,
                            background: 'https://i.ibb.co/fkFmQC2/eve.jpg'
                        }, 'apikey')
	await conn.replyWithPhoto({ url: lea })
})



// Función qu
async function startsenna() {
    bot.on('callback_query', async (conn) => {
        //console.log(conn)
        action = conn.callbackQuery.data.split(' ')
        args = action
     
        
        user_id = Number(action[1])
        if (conn.callbackQuery.from.id != user_id) return conn.answerCbQuery('✳️ Este botón no es para tí', {
            show_alert: true
        })
        const timestampi = speed();
        const latensii = speed() - timestampi
        const user = simple.getUserName(conn.callbackQuery.from)
        const {
            isUrl,
            fetchJson
        } = simple
        const pushname = user.full_name;
        const username = user.username ? user.username : "fg98f";
        const isCreator = [conn.botInfo.username, ...global.OWNER].map(v => v.replace("https://t.me/", '')).includes(user.username ? user.username : "-")
        const reply = async (text) => {
            for (var x of simple.range(0, text.length, 4096)) { //max 4096
                return await conn.replyWithMarkdown(text.substr(x, 4096), {
                    disable_web_page_preview: true
                })
            }
        }
        try {
        	
            switch (action[0]) {
                

                case "allmenu": {
                    lang.allmenu(conn, THUMBNAIL, user_id.toString())
                }
                break
                
                case "owner": {
                    await conn.sendContact(OWNER_NUMBER, OWNER_NAME)
                    reply(`Creador: [${OWNER_NAME}](${OWNER[0]}) 👑`)
                }
                break
                case 'ytmp3': {
    if (!args[2]) return await reply(`✳️Ejemplo: ${prefix + command} https://youtu.be/YzkTFFwxtXI`);

    try {
        const res = await fgdl.ytmp3(args[2]); // Descargar el audio y obtener la información
        const { title, dl_url } = res; // Extraer el título y la URL de descarga del audio

        await conn.sendChatAction('upload_audio');

        const audioStream = fs.createReadStream(dl_url); // Crear un flujo de lectura desde el archivo de audio descargado
        await conn.sendAudio({ source: audioStream }, { title: title }); // Enviar el audio
        
    } catch {
        reply(`✳️ Error: intente más tarde`);
    }
}
break
                
                case "ytmp4": {
                    if (!args[2]) return await reply(`✳️Ejemplo: ${prefix + command} https://youtu.be/YzkTFFwxtXI`)
	
try {	
		let q = args[3] || '360p'	
		let res = await fetch(global.API('fgmods', '/api/downloader/ytmp4', { url: args[2], quality: q}, 'apikey'))
        let yt = await res.json()
        let { title, dl_url, quality, size, sizeB } = yt.result
         
         await conn.sendChatAction('upload_video')
        reply('✳️descargando')
		
		let mp = `
	≡  FG YTDL
  
📌Título: ${title}
🎞️Calidad: ${q}
⚖️Tamaño: ${size}
`

              // await conn.replyWithPhoto({ url: "https://i.imgur.com/bbWbASn.jpg" }, { caption: mp, parse_mode: 'Markdown'})

                   await conn.replyWithVideo({ url: dl_url }, { caption: mp })
                  } catch {
                  	reply(`✳️ Error: intente más tarde`) 
                  	} 
                }
                break
                
                //--
            }
        } catch (e) {
            console.log(e)
        }
    })
    

    bot.command('start', async (conn) => {
        let user = simple.getUserName(conn.message.from)
        
       let capt = `¡Hola ${user.full_name}! Mi nombre es ${BOT_NAME}. ¡Soy un bot de Telegram multifunción! Haz clic en /help para obtener más información sobre cómo usar este bot.

Únete a [mi canal](https://t.me/fgawgp) para recibir información sobre todas las últimas actualizaciones.`

        await conn.reply(capt, {
            parse_mode: "MARKDOWN",
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: [
                    [{
                        text: 'Script',
                        url: "https://github.com/FG98F/tg-senna-bot"
                    }, {
                        text: 'Owner',
                        url: OWNER[0]
                    }]
                ]
            }
        })
    })
    bot.on('message', async (conn) => {
        require("./index")(conn, bot)
    })

    bot.launch({
        dropPendingUpdates: true
    })

    bot.telegram.getMe().then((getme) => {
        console.table({
            "Bot Name": getme.first_name,
            "Username": "@" + getme.username,
            "ID": getme.id,
            "Link": `https://t.me/${getme.username}`,
            "Author": "https://t.me/fg98f"
        })
    })
   
}


startsenna()

process.once('SIGINT', () => bot.stop('SIGINT'))
process.once('SIGTERM', () => bot.stop('SIGTERM'))