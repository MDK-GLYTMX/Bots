require("./settings")
const {
    Telegraf, 
    Context
} = require('telegraf')
const {
    message,
    editedMessage,
    channelPost,
    editedChannelPost,
    callbackQuery
} = require("telegraf/filters");
const chalk = require('chalk')
const fs = require('fs')
const fetch = require('node-fetch')
const axios = require('axios')
const os = require('os')
const speed = require('performance-now')
const util = require('util')

const yts = require('yt-search')
const { pipeline } = require('stream') 
const { promisify } = require('util') 
const ytdl = require('ytdl-core')

const {
    simple
} = require('./lib/myfunc')

const fgdl = require('./lib/ytdl-core') 
const fg = require('api-dylux')  

module.exports = conn = async (conn, bot) => {
    //console.log(conn)
    try {
        const body = conn.message.text || conn.message.caption || ''
        const budy = (typeof conn.message.text == 'string' ? conn.message.text : '')
        const {
            isUrl
        } = simple
        const isCmd = /^[°•π÷×¶∆£¢€¥®™�✓_=|~!?#/$%^&.+-,\\\©^]/.test(body)
        const prefix = isCmd ? body[0] : ''
        const command = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ''
       
        const args = body.trim().split(/ +/).slice(1)
        const text = q = args.join(" ")
        const user = simple.getUserName(conn.message.from)
        const pushname = user.full_name;
        const user_id = conn.message.from.id + " "
        const username = conn.message.from.username ? conn.message.from.username : "fg98f";
        const isCreator = OWNER[0].replace("https://t.me/", '') == conn.update.message.from.username
        const from = conn.message.chat.id

        const isGroup = conn.chat.type.includes('group')
        const groupName = isGroup ? conn.chat.title : ''


//--- ping 
const speed = () => {
    const timestamp = new Date();
    return timestamp.getTime();
};
//---  


        const isImage = conn.message.hasOwnProperty('photo')
        const isVideo = conn.message.hasOwnProperty('video')
        const isAudio = conn.message.hasOwnProperty('audio')
        const isSticker = conn.message.hasOwnProperty('sticker')
        const isContact = conn.message.hasOwnProperty('contact')
        const isLocation = conn.message.hasOwnProperty('location')
        const isDocument = conn.message.hasOwnProperty('document')
        const isAnimation = conn.message.hasOwnProperty('animation')
        const isMedia = isImage || isVideo || isAudio || isSticker || isContact || isLocation || isDocument || isAnimation
        const quotedMessage = conn.message.reply_to_message || {}
        const isQuotedImage = quotedMessage.hasOwnProperty('photo')
        const isQuotedVideo = quotedMessage.hasOwnProperty('video')
        const isQuotedAudio = quotedMessage.hasOwnProperty('audio')
        const isQuotedSticker = quotedMessage.hasOwnProperty('sticker')
        const isQuotedContact = quotedMessage.hasOwnProperty('contact')
        const isQuotedLocation = quotedMessage.hasOwnProperty('location')
        const isQuotedDocument = quotedMessage.hasOwnProperty('document')
        const isQuotedAnimation = quotedMessage.hasOwnProperty('animation')
        const isQuoted = conn.message.hasOwnProperty('reply_to_message')
        const timestampi = speed();
        const latensii = speed() - timestampi

        //-- reply edit 
        const replyE = async (text) => {
            for (var x of simple.range(0, text.length, 4096)) { //maks 4096 character, jika lebih akan eror
                return await conn.replyWithMarkdown(text.substr(x, 4096), {
                    disable_web_page_preview: true
                })
            }
        }
        //--
        const reply = async (text) => {
       for (var x of simple.range(0, text.length, 4096)) {
        await conn.replyWithMarkdown(text.substr(x, 4096), {
            disable_web_page_preview: true,
            reply_to_message_id: conn.message.message_id // Utiliza directamente el message_id del mensaje recibido
        });
    }
}
   
        //get type message 
        var typeMessage = body.substr(0, 50).replace(/\n/g, '')
        if (isImage) typeMessage = 'Image'
        else if (isVideo) typeMessage = 'Video'
        else if (isAudio) typeMessage = 'Audio'
        else if (isSticker) typeMessage = 'Sticker'
        else if (isContact) typeMessage = 'Contact'
        else if (isLocation) typeMessage = 'Location'
        else if (isDocument) typeMessage = 'Document'
        else if (isAnimation) typeMessage = 'Animation'

        //push message to console
        /*if (conn.message) {
            console.log(chalk.black(chalk.bgWhite('[ CMD ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(body || typeMessage)) + '\n' + chalk.magenta('=> From'), chalk.green(pushname) + '\n' + chalk.blueBright('=> In'), chalk.green(isGroup ? groupName : 'Private Chat', conn.message.chat.id))
        }*/
        
    if (conn.message) {
    const botInfo = await conn.telegram.getMe();
    const botName = botInfo.first_name;
    const botUsername = botInfo.username;

    // Get current time in Argentina/Buenos Aires time zone
    const currentTime = new Date().toLocaleString('es-ES', { timeZone: 'America/Argentina/Buenos_Aires' })

    const chatType = isGroup ? 'Grupo' : 'Chat Privado';
    const groupOrUserName = isGroup ? groupName : pushname;

    console.log(`
 
${chalk.hex('#FE0041').bold('┎━─━─━─━─  ⌬  ─━━──━━──━')}
🤖 ${chalk.cyan(`${botName}`)} ${chalk.green(`~ @${botUsername}`)}
⏱️ ${chalk.black(chalk.bgGreen(currentTime))} 
👤 ${chalk.cyan(`${pushname}`)} ${chalk.green(`~ @${username}`)}  ${chalk.red('En')} 
👥 ${chalk.cyan(`${chatType}`)}   ${chalk.green(`~ ${groupOrUserName}`)}
${chalk.hex('#FE0041').bold('┕━─━─━─━─━─━─━━──━━──━')}
${chalk.green(`Chat`)}: ${isCmd ? chalk.hex('#F6FF2E')(prefix + command) : prefix ? chalk.hex('#F6FF2E')(prefix) : ''}${isCmd ? ' ' : ''}${isCmd ? chalk.blue(body.slice(1)) : chalk.blue(body)}
`.trim());
}




        switch (command) {
            

            case 'owner':
            case 'creator': {
                await conn.sendContact(OWNER_NUMBER, OWNER_NAME)
                reply(`Creador: [${OWNER_NAME}](${OWNER[0]}) 👑`)
            }
            break
            case 'sc':
            case 'script':
            case 'scrip': {
                conn.reply("Codigo del Bot", {
                    reply_markup: {
                        inline_keyboard: [
                            [{
                                text: 'Github',
                                url: "https://github.com/FG98F/tg-senna"
                            }, {
                                text: 'YouTube',
                                url: "https://www.youtube.com/@fg98f"
                            }]
                        ]
                    }
                })
            }
            break
            
            case 'menu':
            case 'help': {
                
                let dnew = new Date(new Date + 3600000)
                let week = dnew.toLocaleDateString('es', {
                    weekday: 'long'
                })
                let date = dnew.toLocaleDateString('es', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                })
                
                
                lang.menu(conn, THUMBNAIL, pushname, OWNER_NAME, OWNER, prefix, os, simple, week, date, username, isCreator, conn.message.from.id.toString())
            }
            break
            
            case 'runtime':
            case 'uptime': {
const runtimeInSeconds = process.uptime();
const days = Math.floor(runtimeInSeconds / (60 * 60 * 24));
const hours = Math.floor((runtimeInSeconds % (60 * 60 * 24)) / (60 * 60));
const minutes = Math.floor((runtimeInSeconds % (60 * 60)) / 60);
const seconds = Math.floor(runtimeInSeconds % 60);

const runtimeFormatted = `${days}d ${hours}h ${minutes}m`

    reply(`🏮 Tiempo activo\n\n${runtimeFormatted}`);
}
break

case 'ping': {
    const startTimestamp = speed();
    replyE('Calculando velocidad...').then((sentMessage) => {
        const endTimestamp = speed();
        const botLatency = endTimestamp - startTimestamp;
        const response = `🟢 Velocidad: ${botLatency}ms`;
        conn.telegram.editMessageText(conn.message.chat.id, sentMessage.message_id, null, response);
    });
}
break
   
       case 'donar':
       case 'donate':
  let donacionText = `
≡ Puedes donar si quieres mantener el bot activo

▢ *PayPal*
• [Link](https://paypal.me/fg98f)

▢ *Mercado Pago Arg*
• Alias : fgmods

▢ *Naranja X Arg*
• *Alias:* fgmods2
`;

const img = 'https://i.ibb.co/37FP2bk/donate.jpg';
await conn.replyWithPhoto({ url: img}, { caption: donacionText, parse_mode: 'Markdown', reply_to_message_id: conn.message.message_id })
break

    
    case 'play': {
              if (!text) return await reply(`✳️ Ejemplo: ${prefix + command} Lil peep Hate my life`);

    const searchResult = await yts(text);
    const video = searchResult.videos[0];

    if (!video) return await reply('Vídeo/Audio no encontrado.');

    const { title, timestamp, views, ago, url, thumbnail } = video;

    const playCaption = `
      ≡ *FG MUSIC*
┌──────────────
▢ 📌 Título: ${title}
▢ 📆 Subido: ${ago}
▢ ⌚ Duración: ${timestamp}
▢ 👀 Vistas: ${views.toLocaleString()}
└──────────────`;
      
                conn.replyWithPhoto({
                    url: thumbnail
                }, {
                    caption: playCaption,
                    parse_mode: 'MARKDOWN',
                    reply_markup: {
                        inline_keyboard: [
                            [{
                                    text: '🎶 MP3',
                                    callback_data: 'ytmp3 ' + user_id + url 
                                },
                                {
                                    text: '🎥 MP4',
                                    callback_data: 'ytmp4 ' + user_id + url
                                }
                            ]
                        ]
                    }, 
                    reply_to_message_id: conn.message.message_id
                })
                
            }
            break
            
             case 'ytmp4': {
                            
if (!text) return await reply(`✳️Ejemplo: ${prefix + command} https://youtu.be/YzkTFFwxtXI`)
		
		try {
		let q = args[1] || '360p'	
		let res = await fetch(global.API('fgmods', '/api/downloader/ytmp4', { url: args[0], quality: q}, 'apikey'))
        let yt = await res.json()
        let { title, dl_url, quality, size, sizeB } = yt.result
         await conn.sendChatAction('upload_video')
	
	
		let mp = `
	≡  FG YTDL
  
📌Título: ${title}
🎞️Calidad: ${q}
⚖️Tamaño: ${size}
`
          
              // await conn.replyWithPhoto({ url: "https://i.imgur.com/bbWbASn.jpg" }, { caption: mp, parse_mode: 'Markdown'})

                   await conn.replyWithVideo({ url: dl_url }, { caption: mp, reply_to_message_id: conn.message.message_id })
                   
                    } catch {
                  	reply(`✳️ Error: intente más tarde`) 
                  	} 
                
            }
            break
            
        case 'ytmp3': {
    if (!text) return await reply(`✳️Ejemplo: ${prefix + command} https://youtu.be/YzkTFFwxtXI`);

    try {
        const res = await fgdl.ytmp3(args[0]); // Descargar el audio y obtener la información
        const { title, dl_url } = res; // Extraer el título y la URL de descarga del audio

        await conn.sendChatAction('upload_audio');

        const audioStream = fs.createReadStream(dl_url); // Crear un flujo de lectura desde el archivo de audio descargado
        await conn.sendAudio({ source: audioStream}, { title: title, reply_to_message_id: conn.message.message_id}); // Enviar el audio
        
    } catch {
        reply(`✳️ Error: intente más tarde`);
    }
}
break
     
            case 'yts':
            case 'ytsearch': {
                if (!text) return await reply(`✳️ Ejemplo: **${prefix + command}** Lil peep bye bye baby`);
  
    let results = await yts(text);
    let videos = results.videos;
    cap = videos.map(video => {
      return `
📌 ${video.title}
⌚Duración: ${video.timestamp}
📆Subido: ${video.ago}
👀Vistas: ${video.views}
🔗Link: ${video.url}
      `.trim();
    }).join('\n--------------------------\n');

    //await conn.replyWithPhoto({ url: videos[0].image }, { caption: cap, parse_mode: 'Markdown' });
    await reply(cap)
   } 
            break
            
            case "ig":
            case "instagram":
            case "igdl": {
	if (!args[0]) throw `✳️ Ejemplo\n ${prefix + command} https://www.instagram.com/p/CYHeKxyMj-J/?igshid=YmMyMTA2M2Y=`
    let res = await fetch(global.API('fgmods', '/api/downloader/igdl', { url: args[0] }, 'apikey'))
    let data = await res.json()

try {
    for (let item of data.result) {
        // Verificar el tipo MIME del archivo
        const response = await fetch(item.url);
        const contentType = response.headers.get('content-type');
        

        if (contentType && contentType.startsWith('image')) {
        	await conn.sendChatAction('upload_photo')
            await conn.replyWithPhoto({ url: item.url}, { caption: `✅ Resultado de la descarga`, reply_to_message_id: conn.message.message_id } );
        } else {
            await conn.sendChatAction('upload_video')
            
            await conn.replyWithVideo({ url: item.url }, { caption: `✅ Resultado de la descarga`, reply_to_message_id: conn.message.message_id });
        }
    }
   } catch {
   	reply(`✳️ Error: intente más tarde`) 
   	} 
}
break;

            
            
            case "tiktok":
            case "ttdl": {
                if (!args[0]) throw `✳️ Ingrese un link de Tiktok\n\n 📌 Ejemplo : ${prefix + command} https://vm.tiktok.com/ZMYG92bUh/`
        if (!args[0].match(/tiktok/gi)) throw `❎ La Url no es de Tiktok`
        
      try {
        let res = await fetch(global.API('fgmods', '/api/downloader/tiktok', { url: args[0] }, 'apikey'))
        let data = await res.json()

        if (!data.result.images) {
        	await conn.sendChatAction('upload_video')
            let tex = `
┌─⊷ TIKTOK DL
▢ Nombre: ${data.result.author.nickname }
▢ Username: ${data.result.author.unique_id}
▢ Duración: ${data.result.duration}
▢ Likes: ${data.result.digg_count}
▢ Vistas: ${data.result.play_count}
└───────────
`
            await conn.replyWithVideo({ url: data.result.play }, { caption: tex, reply_to_message_id: conn.message.message_id })
            
        } else {
        	await conn.sendChatAction('upload_photo')
            let cap = `
▢ Likes: ${data.result.digg_count}
▢ desc: ${data.result.title}
`
            for (let tt of data.result.images) {
                await conn.replyWithPhoto({ url: tt }, { caption: cap }) 
                      
            }
            const response = await axios.get(data.result.play, { responseType: 'arraybuffer' }) // Descargar el audio
              await conn.sendAudio({ source: response.data }, { title: data.result.author.nickname, reply_to_message_id: conn.message.message_id }) // Enviar el audio
             
            
        }
    } catch (error) {
        reply(`❎ Ocurrió un error: ${error}`)
    }
                 
            }
            break
            
            case 'ai':
				case 'ia':
				case 'gpt':
				case 'openai': {
				if (!text) return await reply(`✳️ Repita agregando un texto`);
				await conn.sendChatAction('typing')
				
				try {
				let syst = "Eres DyLux Bot, un gran modelo de lenguaje entrenado por OpenAI. Siga cuidadosamente las instrucciones del usuario. Responde usando Markdown."
				let gpt = await fetch(global.API('fgmods', '/api/info/openai', { prompt: syst, text }, 'apikey'));
                let res = await gpt.json()
                reply(res.result)
                
               } catch {
               	reply(`❎ Error: Intente más tarde`) 
              } 
                
              } 
				break 
				
				case 'gemini': {
				if (!text) return await reply(`✳️ Repita agregando un texto`);
				
				await conn.sendChatAction('typing')
				try {
				let gpt = await fetch(global.API('fgmods', '/api/info/gemini', { text }, 'apikey'));
                let res = await gpt.json()
                reply(res.result)
               } catch {
               	reply(`❎ Error intenta más tarde`) 
                   } 
              } 
				break 
				
				/*case 'getcase': 
const getCase = (cases) => {
return "case"+` '${cases}'`+fs.readFileSync("index.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
reply(`${getCase(text)}`)
break*/
//--- Img 
case 'tvid':
case 'asupan':
case 'video':
let userName = [
    'c.sol_',
    'nuriaarancibiaa',
    'laurasofiadepende',
    'mariana.30027',
    'kyarak_',
    'luly.mix',
    'melodyvalenzuelar',
    'michitasnow',
    'iamjossaryvallejos10',
    'notaestheticallyhannah_',
    '_marinazarrocaa_'
  ]
  let pickuser = userName[Math.floor(Math.random() * userName.length)]
  let query = args[0] ? args[0] : pickuser
  
  try { 
  	let res = await fetch(global.API('fgmods', '/api/img/asupan-tt', { username: query }, 'apikey'))
     let video = await res.json()
     await conn.sendChatAction('upload_video')
     await conn.replyWithVideo({ url: video.result }, { caption: "✅ Resultado", reply_to_message_id: conn.message.message_id })
     
  	 } catch (error) {
     let img = await global.api('fgmods', '/api/img/asupan-la', { }, 'apikey')
     await conn.sendChatAction('upload_video')
    await conn.replyWithVideo({ url: img }, { caption: "✅ Resultado", reply_to_message_id: conn.message.message_id })
    
  }
break

case 'couple':
case 'pareja':
case 'par':
try {
let res = await fetch(global.API('fgmods', '/api/img/couple', {}, 'apikey'))
let json = await res.json()
           await conn.sendChatAction('upload_photo')
            await conn.replyWithPhoto({ url: json.result.boy}, { caption: `✅ chico`, reply_to_message_id: conn.message.message_id } )
            await conn.replyWithPhoto({ url: json.result.girl}, { caption: `✅ chica`, reply_to_message_id: conn.message.message_id } )
           } catch {
           	reply(`✳️ Error: intente más tarde`) 
           	} 
break 

case 'img':
case 'imagen':
case 'gimage':
if (!text) return reply(`✳️ Ejemplo: ${prefix + command} Billie Eilish`) 
try {
  let res = await fg.googleImage(text) 
  await conn.sendChatAction('upload_photo')
  console.log(res) 
       await conn.replyWithPhoto({ url: res[0] }, { caption: `✅ Resultudo`, reply_to_message_id: conn.message.message_id } )
} catch {
	reply(`✳️ Error: intente más tarde`) 
	} 
break 



//--
            default:
        }
    } catch (e) {
        conn.reply(util.format(e))
        console.log('[ ERROR ] ' + e)
    }
}