const fs = require("fs");
const {
   es
} = require("./language");


global.APIs = {
   fgmods: 'https://api.fgmods.xyz' 
}


global.APIKeys = {
   'https://api.fgmods.xyz': 'sett'
}

//language 
global.language = es

global.BOT_TOKEN = "7051252223:AAG84JgDstCzcfJNUsnOwW4C9K0WCn2DczM" //create bot here https://t.me/BotFather and get the bot token
global.BOT_NAME = "Senna" //your bot name
global.OWNER_NAME = "FG98" //your name
global.OWNER_NUMBER = "5491168352204"
global.OWNER = [
"https://t.me/fg98f", 
"https://t.me/fg98_ff"
   ] // username

global.THUMBNAIL = "./src/fg_logo.jpg" 
global.lang = language
